# include <system.h>
# include <altera_avalon_pio_regs.h>
#include <stdio.h>

int main (void){
   	//inputing the two 3x3 matrices
    int a[9] = {1,2,3,5,0,1,2,3,7};
    int b[9] = {3,2,0,0,1,0,5,6,4};

    int c[9];

    int en = 1;

		int i;
		int j;
		int x;


		//multiplication loops
    for( i = 0;i < 3;i++){
        for( j = 0;j < 3;j++){
            c[3*i + j] = 0;
            for( x = 0;x < 3;x++){
                 c[3*i + j] = c[3*i + j] + (a[3*i + x] * b[j + 3*x]);
            }
        }
    }

    for ( int k = 0; k < 9; ++ k )
    {
      en = IORD_ALTERA_AVALON_PIO_DATA(0x21020);
      while(en)
      {

      }
      if ( !en )
      {
        IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, c[k] );
      }
    }
    return 0;
}

